<?php
/**
 * Front and back common functionality.
 *
 * @package    Joinchat
 */

defined( 'WPINC' ) || exit;

/**
 * Front and Back Common class.
 *
 * @since      4.2.0
 * @package    Joinchat
 * @subpackage Joinchat/includes
 * @author     Creame <hola@crea.me>
 */
class Joinchat_Common {

	/**
	 * International Telephone Input library version.
	 *
	 * @since    4.5.10
	 */
	const INTL_TEL_INPUT_VERSION = '29.5.2';

	/**
	 * Singleton instance.
	 *
	 * @since    4.5.0
	 * @var self|null
	 */
	private static $instance = null;

	/**
	 * Settings
	 *
	 * @since    4.5.0
	 * @var null|array
	 */
	public $settings = null;

	/**
	 * Require QR Script on front.
	 *
	 * @since    4.5.0
	 * @var bool
	 */
	public $qr = false;

	/**
	 * Is joinchat preview
	 *
	 * @since    5.0.0
	 * @var bool
	 */
	public $preview = false;

	/**
	 * Instantiates Manager.
	 *
	 * @since    4.5.0
	 * @return Joinchat_Common
	 */
	public static function instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;

	}

	/**
	 * Initialize the class.
	 *
	 * @since    4.2.0
	 * @since    5.0.0 Ensure load settings only once.
	 */
	private function __construct() {

		add_action( 'admin_init', array( $this, 'load_settings' ), 5 );
		add_action( 'wp', array( $this, 'load_settings' ) );

	}

	/**
	 * Return the default settings.
	 *
	 * @since    4.2.0  default_settings()
	 * @since    5.0.0  renamed to defaults() & added $key param.
	 * @param  string|false $key  Setting key or false.
	 * @return mixed
	 */
	public function defaults( $key = false ) {

		$defaults = array(
			'telephone'     => '',
			'mobile_only'   => 'no',
			'button_ico'    => 'app',
			'button_image'  => '',
			'button_tip'    => '',
			'button_delay'  => 3,
			'whatsapp_web'  => 'no',
			'qr'            => 'no',
			'qr_text'       => __( 'Scan the code', 'creame-whatsapp-me' ),
			'message_text'  => '',
			'message_views' => 2,
			'message_delay' => 10, // Disabled on negative values.
			'message_badge' => 'no',
			'message_send'  => '',
			'message_start' => __( 'Open Chat', 'creame-whatsapp-me' ),
			'position'      => 'right',
			'visibility'    => array( 'all' => 'yes' ),
			'color'         => '#25d366/1', // hexcolor/0|1 (black or white text).
			'dark_mode'     => 'no',     // values: 'no', 'yes' or 'auto'.
			'header'        => '__wa__', // values: '__wa__' or other custom text.
			'optin_text'    => '',
			'optin_check'   => 'no',
			'gads'          => '',
			'tracking'      => 'yes',
			'custom_css'    => '',
			'clear'         => 'no',
			'show_brand'    => 'yes',
		);

		$defaults = array_merge( $defaults, apply_filters( 'joinchat_extra_settings', array() ) );

		if ( empty( $key ) ) {
			return $defaults;
		}

		return isset( $defaults[ $key ] ) ? $defaults[ $key ] : false;

	}

	/**
	 * Load saved settings.
	 *
	 * @since    4.2.0
	 * @since    4.5.7  Intitialize intltel.
	 * @since    5.0.0  Only run once and add filter 'joinchat_settings'
	 * @return array
	 */
	public function load_settings() {

		if ( ! is_null( $this->settings ) ) {
			return $this->settings;
		}

		$defaults = $this->defaults();

		// Can hook 'option_joinchat' and 'default_option_joinchat' filters.
		$settings = (array) get_option( JOINCHAT_SLUG, $defaults );

		// Since v6.2.0 use "show_brand" setting.
		if ( ! isset( $settings['show_brand'] ) && isset( $settings['header'] ) ) {
			if ( '__jc__' === $settings['header'] ) {
				$settings['header']     = '__wa__';
				$settings['show_brand'] = 'yes';
			} else {
				$settings['show_brand'] = 'no';
			}
		}

		$settings = array_merge( $defaults, $settings );

		// Since v5.1 use negative values for disabled.
		if ( 0 === $settings['message_delay'] ) {
			$settings['message_delay'] = -1;
		}

		if ( ! $settings['button_ico'] ) {
			$settings['button_ico'] = 'app';
		}

		$settings['color'] = str_replace( '/100', '/1', $settings['color'] );

		// Since 6.4 migrate visibility settings.
		$visibility = isset( $settings['visibility'] ) ? $settings['visibility'] : $defaults['visibility'];

		if ( isset( $visibility['blog_page'] ) ) {
			$visibility['blog'] = $visibility['blog_page'];
			unset( $visibility['blog_page'] );
		}

		if ( isset( $visibility['singular'] ) ) {
			if ( ! isset( $visibility['page'] ) ) {
				$visibility['page'] = $visibility['singular'];
			}
			if ( ! isset( $visibility['post'] ) ) {
				$visibility['post'] = $visibility['singular'];
			}
			unset( $visibility['singular'] );
		}

		if ( isset( $visibility['archive'] ) ) {
			if ( ! isset( $visibility['date'] ) ) {
				$visibility['date'] = $visibility['archive'];
			}
			if ( ! isset( $visibility['author'] ) ) {
				$visibility['author'] = $visibility['archive'];
			}
			unset( $visibility['archive'] );
		}

		$settings['visibility'] = $visibility;

		// Clean unused saved settings.
		$settings = array_intersect_key( $settings, $defaults );

		$this->settings = apply_filters( 'joinchat_settings', $settings );

		return $this->settings;

	}

	/**
	 * Get International Telephone Input library version
	 *
	 * Return IntlTelInput library version or false to disable.
	 *
	 * @since    4.5.10
	 * @since    6.3.0 renamed from get_intltel() to get_iti_version()
	 * @return string|false
	 */
	public function get_iti_version() {

		return apply_filters( 'joinchat_enhanced_phone', self::INTL_TEL_INPUT_VERSION );

	}

	/**
	 * Get public post_types
	 *
	 * @since    4.5.0
	 * @since    6.4.0 Deprecated `joinchat_post_types_meta_box`; use `joinchat_custom_post_types`.
	 * @return array
	 */
	public function get_public_post_types() {

		$post_types = array_keys( get_post_types( array( 'public' => true ) ) );
		$post_types = array_diff( $post_types, array( 'attachment' ) );

		// Legacy filter kept only as deprecated alias.
		$post_types = (array) apply_filters_deprecated(
			'joinchat_post_types_meta_box',
			array( $post_types ),
			'6.4.0',
			'joinchat_post_types'
		);

		// Legacy filter kept only as deprecated alias.
		$post_types = (array) apply_filters_deprecated(
			'joinchat_custom_post_types',
			array( $post_types ),
			'6.4.0',
			'joinchat_post_types'
		);

		$post_types = (array) apply_filters( 'joinchat_post_types', $post_types );

		return array_unique( $post_types );

	}

	/**
	 * Get taxonomies to include Joinchat meta box
	 *
	 * @since    5.0.9
	 * @since    6.4.0 renamed from get_taxonomies_meta_box() to get_public_taxonomies()
	 * @return array
	 */
	public function get_public_taxonomies() {

		$taxonomies = array_keys( get_taxonomies( array( 'publicly_queryable' => true ) ) );
		$taxonomies = array_diff( $taxonomies, array( 'post_format' ) );

		// Legacy filter kept only as deprecated alias.
		$taxonomies = (array) apply_filters_deprecated(
			'joinchat_taxonomies_meta_box',
			array( $taxonomies ),
			'6.4.0',
			'joinchat_taxonomies'
		);

		$taxonomies = (array) apply_filters( 'joinchat_taxonomies', $taxonomies );

		return array_unique( $taxonomies );

	}

	/**
	 * Get object form placeholders
	 *
	 * @since 4.5.0
	 * @param  WP_Post|WP_Term|WP_User $obj  Current post, term or user.
	 * @return array
	 */
	public function get_obj_placeholders( $obj ) {

		return (array) apply_filters(
			'joinchat_metabox_placeholders',
			array(
				'telephone'    => $this->settings['telephone'],
				'message_text' => $this->settings['message_text'],
				'message_send' => $this->settings['message_send'],
			),
			$obj,
			$this->settings
		);

	}

	/**
	 * Get object dynamic variables for form help text
	 *
	 * @since 4.5.0
	 * @param  WP_Post|WP_Term|WP_User $obj  Current post, term or user.
	 * @return array
	 */
	public function get_obj_vars( $obj ) {

		return (array) apply_filters( 'joinchat_metabox_vars', array( 'SITE', 'TITLE', 'HOME', 'URL', 'HREF' ), $obj );

	}

	/**
	 * Get button alternate icons
	 *
	 * Return an array of ico_key => value with the SVG code or svg value if $value is passed.
	 *
	 * @since 6.0.0
	 * @param string $value Icon name.
	 * @return array|string|false
	 */
	public function get_icons( $value = '' ) {

		$icons = array(
			'v1' => file_get_contents( JOINCHAT_DIR . 'admin/img/ico-logo.svg' ),
			'v2' => file_get_contents( JOINCHAT_DIR . 'admin/img/ico-contact.svg' ),
		);

		$icons = (array) apply_filters( 'joinchat_icons', $icons, $value );

		if ( $value ) {
			return array_key_exists( $value, $icons ) ? $icons[ $value ] : false;
		} else {
			return $icons;
		}
	}

	/**
	 * Get theme color values (H, S, L, text)
	 *
	 * Return values Hue, Saturation, Lightness and text color (0 black|1 white).
	 *
	 * @since 6.0.0
	 * @param string $color Hex color code.
	 * @return array (H, S, L, 0|1)
	 */
	public function get_color_values( $color = '' ) {

		$color = empty( $color ) ? $this->settings['color'] : $color;

		list($color, $text) = explode( '/', $color . '/1' );
		list($r, $g, $b)    = sscanf( $color, '#%02x%02x%02x' );
		list($h, $s, $l)    = Joinchat_Util::rgb2hsl( $r, $g, $b );

		return array( $h, $s, $l, (int) $text );

	}
}


/**
 * Returns the One True Instance of Joinchat_Common.
 *
 * @since 5.0.0
 * @return Joinchat_Common
 */
function jc_common() {

	return Joinchat_Common::instance();

}
